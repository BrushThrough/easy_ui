#include<bits/stdc++.h>
using namespace std;

const int N=1<<18;
string t[17];
int a[17][17],b[16]={300,500,200,500,300,400,300,300,400,600,100,600,500,400,300,300};
double dp[10][N];

int weight[N];
double value[N];
int idea[10][N][10];

int lowbit(int x){return x&(-x);}

void init(){
	t[1]="abcdefghij";t[2]="abcdeopklm";
	t[3]="fghajopklm";t[4]="fghijlpfop";
	t[5]="fbhdeopaoz";
	t[6]="rmtuqfgafz";
	t[7]="rstukfghfc";
	t[8]="rstuabhijc";
	t[9]="csafvwaijc";
	t[10]="bmniazhfoz";
    t[11]="mameazabab";
    t[12]="mcmexhabna";
    t[13]="banycgmbmb";
    t[14]="mcmyxgmbnb"; 
    t[15]="bxniclbcmp";
    t[16]="ccafxhbcmj";
    
   	for(int i=1;i<=16;i++)
	for(int j=1;j<=16;j++){
		int sum=0;
		for(int k=0;k<10;k++) if(t[i][k]==t[j][k]) sum++;
		a[i][j]=a[j][i]=sum;
	}
	
    for(int i=0;i<(1<<16);i++){
    	for(int j=0;j<16;j++){
    		if((i>>j) & 1) weight[i]+=b[j];
		}
	}
   int cnt=0,st[17];
   for(int i=0;i<(1<<16);i++,cnt=0){
		if(i==0) {value[i]=0;continue;}
		for(int j=0;j<16;j++){
			if((i>>j) &1)
			{
		      	for(int k=1;k<=cnt;k++) 
	            {
				    if(a[j+1][st[k]+1]) value[i]+=a[j+1][st[k]+1];
				}
		      	st[++cnt]=j;
		    }
		}
	    if(cnt==1) value[i]=10;
		else value[i]/=cnt;
   }
}
	
int main(){
	init();
//	freopen("out2.txt","w",stdout);
    for(int i=0;i<=9;i++)
    for(int j=0;j<(1<<16);j++)dp[i][j]=-1;
	dp[0][0]=0;
	for(int i=1;i<=9;i++)
	for(int j=1;j<(1<<16);j++){
		for(int k=j;k>0;k=(k-1)&j){
			if(k==j) continue;
			if(lowbit((j^k))==(j^k) && weight[j^k]<500) continue;
			if(dp[i-1][k]==-1) continue;
			if((j^k)==(1<<9)) continue;
			if(weight[j^k]>=((i-1)/3+1)*300 && weight[j^k]<=((i-1)/3+1)*300+300 && dp[i-1][k]+value[j^k]>dp[i][j]){
                dp[i][j]=dp[i-1][k]+value[j^k]; idea[i][j][i]=(j^k);
                for(int z=1;z<=i-1;z++) idea  [i][j][z]=idea[i-1][k][z];
            }
		}
		if(i==1){
			if(lowbit(j)==j && weight[j]<500) continue;
			if(j==(1<<9)) continue;
			if(weight[j]>=300 && weight[j]<=600 && value[j]>dp[i][j]){
		            dp[i][j]=value[j];idea[i][j][i]=j;
		    }
		}
	}
	cout<<"�ٶ���i���ӹ������ڵ�i���ӹ��ѣ������ŷ������£�\n";
	for(int i=1;i<=9;i++){
		cout<<"��"<<i<<"���ӹ�����";
		for(int j=0;j<16;j++){
			if(idea[9][(1<<16)-1][i]>>j&1) cout<<j+1<<"��ԭ��"<<b[j]<<"kg  ";
		} 
		cout<<"\n�üӹ�������Ե��Ϊ"<<value[idea[9][(1<<16)-1][i]]<<endl<<endl;
	} 
	cout<<"�ܵ���Ե��Ϊ��"<<dp[9][(1<<16)-1]<<endl;
} 
