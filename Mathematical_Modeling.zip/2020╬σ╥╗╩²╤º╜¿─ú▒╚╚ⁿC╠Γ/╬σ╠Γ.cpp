#include<bits/stdc++.h>
using namespace std;

const int inf=0x3f3f3f3f;
const int N=1<<18;
string t[17];
int a[17][17],b[16]={300,500,200,500,300,400,300,300,400,600,100,600,500,400,300,300};
double cost[9]={400,400,400,500,500,500,600,600,600};
double c[16]={0.88,0.60,0.93,0.90,0.90,0.78,0.70,0.83,0.95,0.87,0.65,0.75,0.8,0.68,0.87,0.83}; 
double spend[9]={2,2,2,1.8,1.8,1.8,1.6,1.6,1.6};

double dp[10][N][3];//��һά��ʾ��ʾ�ɱ� �ڶ�ά��ʾ����0.8�ӹ��������� ����ά��ʾ��Ե�� 

int weight[N];
double value[N];
double rate[N];
int idea[10][N][10];

int lowbit(int x){return x&(-x);}

void init(){
	t[1]="abcdefghij";t[2]="abcdeopklm";
	t[3]="fghajopklm";t[4]="fghijlpfop";
	t[5]="fbhdeopaoz";
	t[6]="rmtuqfgafz";
	t[7]="rstukfghfc";
	t[8]="rstuabhijc";
	t[9]="csafvwaijc";
	t[10]="bmniazhfoz";
    t[11]="mameazabab";
    t[12]="mcmexhabna";
    t[13]="banycgmbmb";
    t[14]="mcmyxgmbnb"; 
    t[15]="bxniclbcmp";
    t[16]="ccafxhbcmj";
    
   	for(int i=1;i<=16;i++)
	for(int j=1;j<=16;j++){
		int sum=0;
		for(int k=0;k<10;k++) if(t[i][k]==t[j][k]) sum++;
		a[i][j]=a[j][i]=sum;
	}
	
    for(int i=0;i<(1<<16);i++){
    	for(int j=0;j<16;j++){
    		if((i>>j) & 1) weight[i]+=b[j];
		}
	}
    for(int i=0;i<(1<<16);i++){
        if(i==0){rate[0]=0;continue;}
        int cnt=0;
        for(int j=0;j<16;j++){
   	    if((i>>j) &1) rate[i]+=c[j],cnt++;
        }
        rate[i]/=cnt;
   }
   int cnt=0,st[17];
   for(int i=0;i<(1<<16);i++,cnt=0){
		if(i==0) {value[i]=0;continue;}
		for(int j=0;j<16;j++){
			if((i>>j) &1)
			{
		      	for(int k=1;k<=cnt;k++) 
	            {
				    if(a[j+1][st[k]+1]) value[i]+=a[j+1][st[k]+1];
				    else value[i]=-1;
				    if(value[i]==-1) break;
				}
				if(value[i]==-1) break;
		      	st[++cnt]=j;
		    }
		}
		if(value[i]==-1) continue;
	    if(cnt==1) value[i]=10;
		else value[i]/=cnt;
   }
	
}
int main(){
	init();
    for(int i=0;i<=9;i++)
    for(int j=0;j<(1<<16);j++)dp[i][j][0]=inf,dp[i][j][1]=-1,dp[i][j][2]=-1;
	dp[0][0][0]=0,dp[0][0][1]=0;dp[0][0][2]=0;
	
	//freopen("out5.txt","w",stdout);
	
	for(int i=1;i<=9;i++)
	for(int j=0;j<(1<<16);j++){
		for(int k=j;k>0;k=(k-1)&j){
			if((j^k)!=0 && lowbit((j^k))==(j^k) && weight[j^k]<500) continue;
			if(dp[i-1][k][0]==inf || dp[i-1][k][1]==-1 ||dp[i-1][k][2]==-1) continue;
			if((j^k)==(1<<9)) continue;
			if((j^k)!=0 && (weight[j^k]<((i-1)/3+1)*300 || weight[j^k]>((i-1)/3+1)*300+300)) continue;
		    if(value[j^k]==-1) continue;
			if(dp[i-1][k][2]+value[j^k]>dp[i][j][2]&&dp[i-1][k][0]+((j^k)!=0?cost[i-1]:0)+spend[i-1]*weight[j^k]<=dp[i][j][0] && dp[i-1][k][1]+(rate[j^k]>=0.8 ? 1:0)>=dp[i][j][1]){
                dp[i][j][0]=dp[i-1][k][0]+((j^k)!=0?cost[i-1]:0)+spend[i-1]*weight[j^k];
			    dp[i][j][1]=dp[i-1][k][1]+(rate[j^k]>=0.8 ? 1:0);
			    dp[i][j][2]=dp[i-1][k][2]+value[j^k];
  	            idea[i][j][i]=(j^k);for(int z=1;z<=i-1;z++) idea[i][j][z]=idea[i-1][k][z];
            }
		}
		int k=0;
		if((j^k)!=0 && lowbit((j^k))==(j^k) && weight[j^k]<500) continue;
		if(dp[i-1][k][0]==inf || dp[i-1][k][1]==-1 || dp[i-1][k][2]==-1) continue;
		if((j^k)==(1<<9)) continue;
		if(value[j^k]==-1) continue;
		if((j^k)!=0 && (weight[j^k]<((i-1)/3+1)*300 || weight[j^k]>((i-1)/3+1)*300+300)) continue;
		if(dp[i-1][k][2]+value[j^k]>dp[i][j][2]&&dp[i-1][k][0]+((j^k)!=0?cost[i-1]:0)+spend[i-1]*weight[j^k]<=dp[i][j][0] && dp[i-1][k][1]+(rate[j^k]>=0.8 ? 1:0)>=dp[i][j][1]){
            dp[i][j][0]=dp[i-1][k][0]+((j^k)!=0?cost[i-1]:0)+spend[i-1]*weight[j^k];
		    dp[i][j][1]=dp[i-1][k][1]+(rate[j^k]>=0.8 ? 1:0);
		    dp[i][j][2]=dp[i-1][k][2]+value[j^k];
            idea[i][j][i]=(j^k);for(int z=1;z<=i-1;z++) idea[i][j][z]=idea[i-1][k][z];
        }	
	}
	cout<<"�ٶ���i���ӹ������ڵ�i���ӹ��ѣ������ŷ������£�\n";
	for(int i=1;i<=9;i++){
		cout<<"��"<<i<<"���ӹ�����";
        int cnt=0;
		for(int j=0;j<16;j++){
			if(idea[9][(1<<16)-1][i]>>j&1) cout<<j+1<<"��ԭ��"<<b[j]<<"kg    ",cnt++;
		} 
		if(cnt==0) cout<<"�üӹ�����װ�κ�ԭ��"; 
		else cout<<"  \n�üӹ����ӹ��ɱ�Ϊ:"<<cost[i-1]+spend[i-1]*weight[idea[9][(1<<16)-1][i]]<<" ������Ϊ:"<<rate[idea[9][(1<<16)-1][i]]<<" �üӹ�������Ե��Ϊ"<<value[idea[9][(1<<16)-1][i]];
		cout<<endl<<endl;
	} 
	cout<<"�ܵļӹ��ɱ�Ϊ��"<<dp[9][(1<<16)-1][0]<<"  "<<"�ܵĳ���80%�ܺ��ʵļӹ�������Ϊ��"<<dp[9][(1<<16)-1][1]<<" �ܵ���Ե��Ϊ: "<<dp[9][(1<<16)-1][2]<<endl;
} 
