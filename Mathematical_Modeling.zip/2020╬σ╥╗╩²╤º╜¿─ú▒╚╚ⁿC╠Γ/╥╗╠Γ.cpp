#include<bits/stdc++.h>
using namespace std;

string t[17];
int a[17][17],b[16]={300,500,200,500,300,400,300,300,400,600,100,600,500,400,300,300};

void init(){
	t[1]="abcdefghij";t[2]="abcdeopklm";
	t[3]="fghajopklm";t[4]="fghijlpfop";
	t[5]="fbhdeopaoz";
	t[6]="rmtuqfgafz";
	t[7]="rstukfghfc";
	t[8]="rstuabhijc";
	t[9]="csafvwaijc";
	t[10]="bmniazhfoz";
    t[11]="mameazabab";
    t[12]="mcmexhabna";
    t[13]="banycgmbmb";
    t[14]="mcmyxgmbnb"; 
    t[15]="bxniclbcmp";
    t[16]="ccafxhbcmj";
    
   	for(int i=1;i<=16;i++)
	for(int j=1;j<=16;j++){
		int sum=0;
		for(int k=0;k<10;k++) if(t[i][k]==t[j][k]) sum++;
		a[i][j]=a[j][i]=sum;
	}

}
	
int main(){
	init();
//	freopen("out1.txt","w",stdout); 
    for(int i=1;i<=16;i++)
    for(int j=i+1;j<=16;j++){
    	cout<<i<<"��"<<j<<"֮�����ԵֵΪ"<<a[i][j]<<endl; 
	}
} 
