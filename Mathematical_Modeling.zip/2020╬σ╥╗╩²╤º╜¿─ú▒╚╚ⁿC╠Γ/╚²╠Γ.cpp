#include<bits/stdc++.h>
using namespace std;

const int N=1<<18;
string t[17];
int a[17][17],b[16]={300,500,200,500,300,400,300,300,400,600,100,600,500,400,300,300};
double c[16]={0.88,0.60,0.93,0.90,0.90,0.78,0.70,0.83,0.95,0.87,0.65,0.75,0.8,0.68,0.87,0.83}; 
double dp[10][N];

int weight[N];
double rate[N];
double value[N];
int idea[10][N][10];

int lowbit(int x){return x&(-x);}

void init(){
	t[1]="abcdefghij";t[2]="abcdeopklm";
	t[3]="fghajopklm";t[4]="fghijlpfop";
	t[5]="fbhdeopaoz";
	t[6]="rmtuqfgafz";
	t[7]="rstukfghfc";
	t[8]="rstuabhijc";
	t[9]="csafvwaijc";
	t[10]="bmniazhfoz";
    t[11]="mameazabab";
    t[12]="mcmexhabna";
    t[13]="banycgmbmb";
    t[14]="mcmyxgmbnb"; 
    t[15]="bxniclbcmp";
    t[16]="ccafxhbcmj";
    
   	for(int i=1;i<=16;i++)
	for(int j=1;j<=16;j++){
		int sum=0;
		for(int k=0;k<10;k++) if(t[i][k]==t[j][k]) sum++;
		a[i][j]=a[j][i]=sum;
	}
	
    for(int i=0;i<(1<<16);i++){
    	for(int j=0;j<16;j++){
    		if((i>>j) & 1) weight[i]+=b[j];
		}
	}
	
   for(int i=0;i<(1<<16);i++){
   	    if(i==0){rate[0]=-1;continue;}
   	    int cnt=0;
   	    for(int j=0;j<16;j++){
   	   	    if((i>>j) &1) rate[i]+=c[j],cnt++;
	    }
	    rate[i]/=cnt;
   }
   
   int cnt=0,st[17];
   for(int i=0;i<(1<<16);i++,cnt=0){
		if(i==0) {value[i]=0;continue;}
		for(int j=0;j<16;j++){
			if((i>>j) &1)
			{
		      	for(int k=1;k<=cnt;k++) 
	            {
				    if(a[j+1][st[k]+1]) value[i]+=a[j+1][st[k]+1];
				    else value[i]=-1;
				    if(value[i]==-1) break;
				}
				if(value[i]==-1) break;
		      	st[++cnt]=j;
		    }
		}
		if(value[i]==-1) continue;
	    if(cnt==1) value[i]=10;
		else value[i]/=cnt;
   }
}
int main(){
	init();
    for(int i=0;i<=9;i++)
    for(int j=0;j<(1<<16);j++)dp[i][j]=-1;
	dp[0][0]=0;
	freopen("out3.txt","w",stdout);
	for(int i=1;i<=9;i++)
	for(int j=1;j<(1<<16);j++){
		for(int k=j;k>0;k=(k-1)&j){
			if(k==j) continue;
			if(lowbit((j^k))==(j^k) && weight[j^k]<500) continue;
			if(dp[i-1][k]==-1) continue;
			if((j^k)==(1<<9)) continue;
			if(value[j^k]==-1) continue;
			if(weight[j^k]>=((i-1)/3+1)*300 && weight[j^k]<=((i-1)/3+1)*300+300 && dp[i-1][k]+(rate[j^k]>=0.8 ? 1:0)>dp[i][j]){
                dp[i][j]=dp[i-1][k]+(rate[j^k]>=0.8 ? 1:0); idea[i][j][i]=(j^k);
                for(int z=1;z<=i-1;z++) idea[i][j][z]=idea[i-1][k][z];
            }
		}
		if(i==1){
			if(lowbit(j)==j && weight[j]<500) continue;
			if(j==(1<<9)) continue;
			if(weight[j]>=300 && weight[j]<=600 && (rate[j]>=0.8 ? 1:0)>dp[i][j]){
		            dp[i][j]=(rate[j]>=0.8 ? 1:0);idea[i][j][i]=j;
		    }
		}
	}
	cout<<"�ٶ���i���ӹ������ڵ�i���ӹ��ѣ������ŷ������£�\n";
	for(int i=1;i<=9;i++){
		cout<<"��"<<i<<"���ӹ�����";
		for(int j=0;j<16;j++){
			if(idea[9][(1<<16)-1][i]>>j&1) cout<<j+1<<"��ԭ��"<<b[j]<<"kg  ";
		} 
		cout<<"\n�üӹ������ܺ���Ϊ"<<rate[idea[9][(1<<16)-1][i]]<<endl<<endl;
	} 
	cout<<"�ܵĳ���80%�ܺ��ʵļӹ�������Ϊ��"<<dp[9][(1<<16)-1]<<endl;
} 
